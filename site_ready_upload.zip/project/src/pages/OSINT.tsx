import { motion } from 'framer-motion';
import { ArrowLeft, ArrowRight, CheckCircle, Eye, Users, Database, Code, AlertCircle } from 'lucide-react';
import { Link } from 'react-router-dom';
import AnimatedSection from '../components/ui/AnimatedSection';

export default function OSINT() {
  const features = [
    "Infrastructure exposée",
    "Surface humaine",
    "Fuites de credentials",
    "Empreinte technique",
    "Sous-domaines & DNS",
    "Repos GitHub & pastebins"
  ];

  const testAreas = [
    {
      icon: Code,
      title: "Infrastructure exposée",
      description: "Sous-domaines actifs et oubliés, services exposés sur internet, certificats SSL révélant des actifs cachés, buckets cloud mal configurés, ports et services accessibles publiquement."
    },
    {
      icon: Users,
      title: "Surface humaine",
      description: "Employés identifiables, rôles et responsabilités exposés, adresses email professionnelles reconstituables, présence sur les forums techniques et réseaux sociaux, informations exploitables pour du spear phishing ciblé."
    },
    {
      icon: Database,
      title: "Fuites de données",
      description: "Credentials d'employés présents dans des bases de données compromises, documents internes indexés publiquement, informations sensibles exposées dans des repos GitHub publics ou des pastebins."
    },
    {
      icon: Eye,
      title: "Empreinte technique",
      description: "Technologies et versions détectables, prestataires et fournisseurs identifiables, dépendances tierces exposées, historique DNS et changements d'infrastructure."
    }
  ];

  const deliverables = [
    {
      title: "Rapport de cartographie complet",
      description: "Documentation de l'intégralité de votre surface d'attaque externe visible — chaque asset exposé, chaque fuite identifiée, chaque vecteur d'entrée potentiel pour un attaquant."
    },
    {
      title: "Niveau de risque par catégorie",
      description: "Infrastructure, humain, données, technique — avec une priorisation claire des actions à mener."
    },
    {
      title: "Recommandations concrètes",
      description: "Quoi retirer d'internet, quoi surveiller en continu, quels employés sensibiliser en priorité, quels credentials changer immédiatement."
    },
    {
      title: "Durée & modalités",
      description: "3 à 5 jours ouvrés. Travail exclusivement depuis des sources ouvertes et légales. Vous nous fournissez uniquement votre nom de domaine principal et le nom légal de votre société."
    }
  ];

  return (
    <div className="min-h-screen bg-[#0D1117]">
      <section className="relative pt-32 pb-20 px-4 overflow-hidden">
        <div className="absolute inset-0">
          <img
            src="https://images.pexels.com/photos/1181671/pexels-photo-1181671.jpeg?auto=compress&cs=tinysrgb&w=1920"
            alt=""
            className="w-full h-full object-cover opacity-[0.04]"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-[#0D1117]/80 via-[#0D1117]/95 to-[#0D1117]"></div>
          <div className="absolute inset-0 bg-gradient-to-b from-[#E63946]/5 via-transparent to-transparent"></div>
        </div>

        <div className="max-w-6xl mx-auto relative z-10">
          <Link
            to="/services"
            className="inline-flex items-center gap-2 text-[#E63946] hover:text-[#E63946]/80 transition-colors mb-8 group"
          >
            <ArrowLeft className="w-4 h-4 group-hover:-translate-x-1 transition-transform" />
            Retour aux services
          </Link>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <h1 className="text-5xl md:text-6xl font-bold mb-6 text-white">
              OSINT
            </h1>
            <p className="text-xl md:text-2xl text-white/90 mb-8 max-w-3xl leading-relaxed">
              Avant de lancer une attaque, un adversaire passe des heures à vous observer. Il cartographie vos employés, identifie vos sous-domaines exposés, collecte vos credentials fuités. Légalement. Sans que vous le sachiez.
            </p>
            <p className="text-lg text-[#8B949E] max-w-3xl leading-relaxed">
              Une mission OSINT, c'est reproduire exactement ce travail de reconnaissance pour vous montrer ce qu'un attaquant voit de vous — avant qu'il ne passe à l'action.
            </p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="mt-12 grid grid-cols-2 md:grid-cols-3 gap-4"
          >
            {features.map((feature, index) => (
              <div
                key={index}
                className="flex items-center gap-2 text-white/90 bg-[#161B22] backdrop-blur-sm px-4 py-3 rounded-lg border border-white/[0.06]"
              >
                <CheckCircle className="w-5 h-5 text-[#E63946] flex-shrink-0" />
                <span className="text-sm">{feature}</span>
              </div>
            ))}
          </motion.div>
        </div>
      </section>

      <AnimatedSection className="py-20 px-4">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-3xl md:text-4xl font-bold mb-4 text-center text-white">
            Ce qu'on cartographie concrètement
          </h2>
          <p className="text-[#8B949E] text-center mb-12 max-w-3xl mx-auto">
            Nous travaillons exclusivement depuis des sources ouvertes et légales — aucune intrusion, aucun accès non autorisé. Vous nous fournissez uniquement votre nom de domaine principal et le nom légal de votre société. Nous faisons le reste.
          </p>

          <div className="grid md:grid-cols-2 gap-6">
            {testAreas.map((area, index) => {
              const Icon = area.icon;
              return (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                  className="bg-[#161B22] backdrop-blur-sm border border-white/[0.06] rounded-xl p-6 hover:border-[#E63946]/50 transition-all group"
                >
                  <Icon className="w-12 h-12 text-[#E63946] mb-4 group-hover:scale-110 transition-transform" />
                  <h3 className="text-xl font-semibold mb-3 text-white">{area.title}</h3>
                  <p className="text-[#8B949E] leading-relaxed">{area.description}</p>
                </motion.div>
              );
            })}
          </div>
        </div>
      </AnimatedSection>

      <AnimatedSection className="py-20 px-4 bg-[#161B22]/30">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-3xl md:text-4xl font-bold mb-12 text-center text-white">
            Ce que vous recevez
          </h2>

          <div className="grid md:grid-cols-2 gap-6">
            {deliverables.map((item, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                className="bg-[#161B22] backdrop-blur-sm border border-white/[0.06] rounded-xl p-6 hover:border-[#E63946]/50 transition-all"
              >
                <h3 className="text-xl font-semibold mb-3 text-[#E63946]">{item.title}</h3>
                <p className="text-[#8B949E] leading-relaxed">{item.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </AnimatedSection>

      <AnimatedSection className="py-20 px-4">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-3xl md:text-4xl font-bold mb-12 text-center text-white">
            Pour qui
          </h2>

          <div className="bg-[#161B22] backdrop-blur-sm border border-white/[0.06] rounded-xl p-8 mb-8">
            <ul className="space-y-3 text-white/90">
              <li className="flex items-start gap-3">
                <CheckCircle className="w-5 h-5 text-[#E63946] flex-shrink-0 mt-1" />
                <span>Startups ayant levé des fonds récemment et devenant des cibles visibles</span>
              </li>
              <li className="flex items-start gap-3">
                <CheckCircle className="w-5 h-5 text-[#E63946] flex-shrink-0 mt-1" />
                <span>Entreprises avant une certification ISO 27001 ou un audit de conformité</span>
              </li>
              <li className="flex items-start gap-3">
                <CheckCircle className="w-5 h-5 text-[#E63946] flex-shrink-0 mt-1" />
                <span>DSI souhaitant connaître leur exposition réelle avant d'engager des travaux de sécurité</span>
              </li>
              <li className="flex items-start gap-3">
                <CheckCircle className="w-5 h-5 text-[#E63946] flex-shrink-0 mt-1" />
                <span>Toute organisation voulant voir ce qu'un attaquant voit avant de se faire surprendre</span>
              </li>
            </ul>
          </div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
            className="bg-[#E63946]/10 backdrop-blur-sm border border-[#E63946]/30 rounded-xl p-8"
          >
            <div className="flex items-start gap-4">
              <AlertCircle className="w-6 h-6 text-[#E63946] flex-shrink-0 mt-1" />
              <div>
                <h3 className="text-xl font-bold mb-3 text-[#E63946]">Le saviez-vous ?</h3>
                <p className="text-white/90 leading-relaxed">
                  Cette mission précède souvent un pentest externe ou une simulation de phishing — les deux bénéficient directement des informations collectées lors de la phase OSINT.
                </p>
              </div>
            </div>
          </motion.div>
        </div>
      </AnimatedSection>

      <AnimatedSection className="py-20 px-4">
        <div className="max-w-4xl mx-auto text-center">
          <div className="bg-[#161B22] backdrop-blur-sm border border-white/[0.06] rounded-2xl p-12">
            <h2 className="text-3xl font-bold mb-4 text-white">Prêt à découvrir votre exposition ?</h2>
            <p className="text-[#8B949E] mb-8 max-w-2xl mx-auto leading-relaxed">
              L'OSINT est souvent la première étape d'une stratégie de sécurité globale. Si vous ne savez pas par où commencer, nous proposons un appel de cadrage gratuit de 30 minutes pour identifier les priorités.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
              <Link
                to="/contact"
                className="inline-flex items-center gap-2 bg-[#E63946] text-white px-8 py-4 rounded-lg font-semibold hover:bg-[#E63946]/90 transition-all shadow-lg shadow-[#E63946]/25 hover:shadow-[#E63946]/40 hover:scale-105"
              >
                Demander un devis
                <ArrowRight className="w-4 h-4" />
              </Link>
              <Link
                to="/contact"
                className="inline-flex items-center gap-2 border-2 border-[#E63946] text-[#E63946] px-8 py-4 rounded-lg font-semibold hover:bg-[#E63946]/10 transition-all"
              >
                Appel de cadrage gratuit
              </Link>
            </div>
            <p className="text-[#8B949E] text-sm mt-6">
              Réponse sous 24h · Sans engagement · Confidentiel
            </p>
          </div>
        </div>
      </AnimatedSection>
    </div>
  );
}
